# Week 6 – NLP with PyTorch

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Tokenization, embeddings, RNN/Transformer basics, Hugging Face

## 📚 Learn
- Tokenization, embeddings, RNN/Transformer basics, Hugging Face

## 🧪 Project
**Mental Health Sentiment Analyzer**  
**Dataset:** Mental Health in Tech Survey (+ Twitter API)

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
