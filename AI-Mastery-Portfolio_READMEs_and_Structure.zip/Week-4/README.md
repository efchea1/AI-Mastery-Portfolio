# Week 4 – Supabase Basics

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Tables, CRUD, REST, auth; connect APIs

## 📚 Learn
- Tables, CRUD, REST, auth; connect APIs

## 🧪 Project
**Supabase Health Tracker (backend)**  
**Dataset:** CDC BRFSS

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
