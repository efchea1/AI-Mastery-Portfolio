# Week 17 – Explainable AI

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- SHAP / LIME for model explanations

## 📚 Learn
- SHAP / LIME for model explanations

## 🧪 Project
**Explain Diabetes Risk Model**  
**Dataset:** Pima Indians Diabetes

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
