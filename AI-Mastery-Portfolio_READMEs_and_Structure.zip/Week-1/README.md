# Week 1 – Python Basics & Environment Setup

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Core Python, VS Code, Git/GitHub, virtual environments

## 📚 Learn
- Core Python, VS Code, Git/GitHub, virtual environments

## 🧪 Project
**Health Metrics Calculator — BMI/BMR/Hydration**  
**Dataset:** CDC Nutrition Data

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
