# Week 3 – SQL Fundamentals

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- SELECT, WHERE, JOIN, GROUP BY, aggregation

## 📚 Learn
- SELECT, WHERE, JOIN, GROUP BY, aggregation

## 🧪 Project
**SQL Chronic Disease Analysis**  
**Dataset:** CDC Chronic Disease Indicators

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
