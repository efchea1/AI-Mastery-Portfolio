# Week 21 – Portfolio & Outreach

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Portfolio page, README polish, LinkedIn recap

## 📚 Learn
- Portfolio page, README polish, LinkedIn recap

## 🧪 Project
**Publish top 2–3 projects**  
**Dataset:** —

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
