# Week 18 – Bias & Fairness

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Bias metrics, fairness audits, mitigation

## 📚 Learn
- Bias metrics, fairness audits, mitigation

## 🧪 Project
**Audit Week 6 NLP Model**  
**Dataset:** MIMIC‑III

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
