# Week 14 – Real‑Time AI

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- OpenCV + YOLOv8 live pipeline

## 📚 Learn
- OpenCV + YOLOv8 live pipeline

## 🧪 Project
**Mask Detection System**  
**Dataset:** Face Mask Detection

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
