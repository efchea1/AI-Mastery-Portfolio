# Week 10 – XLA Optimization

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- XLA compilation & performance benchmarking

## 📚 Learn
- XLA compilation & performance benchmarking

## 🧪 Project
**Benchmark JAX vs PyTorch**  
**Dataset:** Reuse Week 5 data

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
