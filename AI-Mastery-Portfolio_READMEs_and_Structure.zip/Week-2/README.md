# Week 2 – Python Functions & OOP

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Functions, classes, error handling, file I/O

## 📚 Learn
- Functions, classes, error handling, file I/O

## 🧪 Project
**Patient Intake CLI App**  
**Dataset:** Synthea Synthetic Patients

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
