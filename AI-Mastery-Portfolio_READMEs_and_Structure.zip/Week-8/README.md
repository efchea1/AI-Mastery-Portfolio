# Week 8 – LangChain + Supabase (RAG)

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Vector DB, retrieval, memory persistence

## 📚 Learn
- Vector DB, retrieval, memory persistence

## 🧪 Project
**Voice Agent with Memory**  
**Dataset:** CDC BRFSS / custom

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
