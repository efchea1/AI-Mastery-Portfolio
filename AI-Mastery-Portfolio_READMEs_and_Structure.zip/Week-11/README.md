# Week 11 – JAX + LangChain Integration

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Use JAX models inside LangChain flows

## 📚 Learn
- Use JAX models inside LangChain flows

## 🧪 Project
**Truth‑Seeking LLM Evaluator**  
**Dataset:** CDC / WHO datasets

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
