# Week 12 – Public Health Dashboard

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Streamlit/Tableau + explainability overlays

## 📚 Learn
- Streamlit/Tableau + explainability overlays

## 🧪 Project
**Explainable AI Dashboard**  
**Dataset:** County Health Rankings

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
