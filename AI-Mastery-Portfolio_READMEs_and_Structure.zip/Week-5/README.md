# Week 5 – PyTorch Basics

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Tensors, datasets, DataLoader, training loop, simple CNN

## 📚 Learn
- Tensors, datasets, DataLoader, training loop, simple CNN

## 🧪 Project
**Skin Lesion Classifier**  
**Dataset:** HAM10000

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
