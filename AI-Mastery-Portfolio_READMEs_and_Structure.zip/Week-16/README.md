# Week 16 – Secure Pipeline

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Logging, encryption, HIPAA basics

## 📚 Learn
- Logging, encryption, HIPAA basics

## 🧪 Project
**Compliance layer for Week 15 API**  
**Dataset:** FDA FAERS

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
