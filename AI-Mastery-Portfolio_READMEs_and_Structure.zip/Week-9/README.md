# Week 9 – JAX Basics

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Arrays, jit, grad, vmap; rebuild PyTorch model

## 📚 Learn
- Arrays, jit, grad, vmap; rebuild PyTorch model

## 🧪 Project
**JAX Skin Classifier**  
**Dataset:** Reuse Week 5 data

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
