# Week 19 – Policy Simulation

**Dates:** _(fill in)_  
**Status:** 🔜 Not started · ⏳ In progress · ✅ Completed

## 🎯 Goals
- Prompting + RAG for policy scenarios

## 📚 Learn
- Prompting + RAG for policy scenarios

## 🧪 Project
**Liberia Policy Simulator**  
**Dataset:** DHS Liberia + WHO GHO

## 📓 Notebooks
| Notebook | Description |
|---|---|
| _(add)_ | _(what it does)_ |

## 🗂️ Code
- `src/` for Python modules and scripts
- `notebooks/` for experiments
- `data/` for datasets (git‑ignored)

## 🔗 Resources
- _(add links: docs, videos, courses)_

## 📊 Results & Notes
- _(screenshots, metrics, reflections)_
